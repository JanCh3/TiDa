/**
 * Divides two numbers and returns the result.
 *
 * @author Jan Chodorski 5D
 *
 * @param {number} number1 - the number that gets devided
 * @param {number} number2 - the number that we divide by
 *
 * @returns {number} The value of the divides numbers
 *
 * @example
 * number1 = 10
 * number2 = 2
 *
 *  result = divide(number1, number2)
 *  console.log(result)
 *  // Logs: 5
 *
 * @throws {Error} When the number we divide by is 0
 *
 */


function divide(number1, number2){
    if(number2 != 0){
        return number1 / number2
    }
    else{
        throw new Error('Cant divide by 0')
    }
}

divide(10, 5)