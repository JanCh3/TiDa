/**
 *  Calculates the area of an circle that has a specific radius
 *
 *  @author Jan Chodorski 5D
 *
 *  @param {number} radius - the radius of the circle
 *
 *  @returns {number} The area of the circle
 *
 *  @throws {Error} When the radius is 0 or lower
 */

function calculateArea(radius) {
    if(radius > 0){
        return 3.14 * (radius * radius)
    }
    else{
        throw new Error('The radius must be over 0')
    }
}

calculateArea(10)