/**
 * Says hello to the person with the name we are getting as a string
 *
 * @author Jan Chodorski 5D
 *
  * @param {string} somebody - name of the person
 *
 * @returns {undefined} an alert saying hello to the person
 */

const sayHello = (somebody) => {
    alert(`Hello ${somebody}`)
 }

