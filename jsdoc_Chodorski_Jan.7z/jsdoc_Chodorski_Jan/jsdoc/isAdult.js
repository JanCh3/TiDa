/**
 * Checks if a person is an adult or not.
 *
 * @param {number} age - the age of a person we are checking
 *
 * @returns {boolean} Returns true if a person is 18 or over and false when the person is under 18
 *
 * @throws {Error} If the age of a person is under 0
 *
 * @author Jan Chodorski 5D
 */

function isAdult(age){
    if(age > 0){
        if(age < 18) return false;
        if(age >= 18) return true;
    }
    else{
        throw new Error('Age of an person must be greater than 0')
    }
}